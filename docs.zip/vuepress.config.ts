import { defineUserConfig } from 'vuepress';
import theme from './vuepress.theme';

export default defineUserConfig({
  base: "/",
  theme,
  debug: true,
  // md中使用到的全局配置，可鞥后续会有用
  // https://v2.vuepress.vuejs.org/zh/reference/config.html#permalinkpattern
  permalinkPattern: null,
  open: false,
  locales: {
    // 键名是该语言所属的子路径
    // 作为特例，默认语言可以使用 '/' 作为其路径。
    "/": {
      lang: "zh-CN",
      title: "VuePress",
      description: "Vue-powered Static Site Generator",
    }
  },
});
