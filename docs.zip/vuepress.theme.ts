import { defaultTheme } from "@vuepress/theme-default";
import type { DefaultThemeOptions } from "@vuepress/theme-default";

// 中文站点配置
const zhCN: DefaultThemeOptions = {
  home: "/",
  navbar: [
    { text: "nihao", link: "/test/" },
    // {
    //   text: "Group",
    //   children: ["/test/"],
    // },
  ],
  repo: 'zc-r/sparrow'
};

export default defaultTheme({
  locales: {
    [zhCN.home]: zhCN,
  },
});