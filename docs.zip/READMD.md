### 参考文献
* [vuepress-theme-hope](https://vuepress-theme-hope.gitee.io/v2/zh/guide/)
* [在线使用vuepress-theme-hope代码](https://stackblitz.com/edit/vuepress-theme-hope-xklkbp?file=package.json)
* [vuepress有趣的插件](https://blog.csdn.net/weixin_42029738/article/details/125833297)
* [vuepress有趣的插件2](https://zhuanlan.zhihu.com/p/467830386)
* [一个需要研究的地方](https://blog.csdn.net/Android_boom/article/details/127193548)
* [Frontmatter](https://blog.csdn.net/weixin_42252518/article/details/99550466)